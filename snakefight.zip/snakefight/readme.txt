   S N A K E   F I G H T 
      version  July 2000 (May-July 2000)
 For playing , copy the files in some directory and 
 run install. Then you can run game from snkstart.exe 
______________________________________________
///Author - ////////////////////////////////////////////////////////////
////////////  Todor Iliev Arnaudov (aka Todor Programmer/TodProg)///////
////////////////////////////////////////////////////////////////////////

 This game is made in Plovdiv,Bulgaria on 
 P90/16ram/1mb s3 trio32/812hdd Western Digital 
 with Borland Pascal 7.
Thanks to Alexei Frounze - most of low graphics routines
(like putting pixel,drawing lines etc.) and for writing text in mode $13 (320x200x256)
 are written by himself.
   e-mail: alexfru@chat.ru
   http:// alexfru.chat.ru 
  In his site you can find links to many other good sites for programming. 
??????????????????????????????????????????????????????????????????????????
/////// System requirements \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
     IBM PC AT machine ! Yes , that's right , this programme
     is compiled to work minimal on Intel 80286, 
   but i don't know how the game runs on that cpu.
 ____________________________________???????????????????????????????????????
  8,5,4,6 (Num lock) - for moving the snake 
  Space            -for choose in any menu  
  Escape     - exit from options ( go to options when you are in the game)
   Q      - QUIT programme 

 _______________________________ ?????????????????????????????????????????
 INSTRUCTIONS: 
    - Run install.exe (if you want to see 3d-intro ) and write destination.
    - Start  <<snkstart.exe>> , it will run first 3dsnake.exe (intro) ,then
  Snake01.exe (the game). 
    - Choose CPU (for properly delays in game ) and press [Enter]
    - Use ESC for pause and quit to OPTIONS.
      -  NEW GAME 
        -   WARP TO LEVEL (choose level 1-11)
         -    CREDITS  (see my name and my friends' names ) 
          -    TIME PLAYED ( How long you're playing this game :) )
           -    CONTROLS   (Change control keys )
            -     LIFES    ( Give to yourself lifes. Not very important, because,
             -               there isn't 'game over' , even you have -100 lifes... :) )
              -    SPEED    ( For detail speed tuning ... For very fast or very slow machines)
               -    QUIT GAME ( Please, don't use it often ;) )
                -    ABOUT     (See little demo of my 2D-vector animation technics ) 
        
 
>___________ CONTACT ME ? DO IT IF YOU HAVE SOMETHING TO SAY ME____________<
  My e-mail is todprog@yahoo.com  
http://www.geocities.com/todprog
http://www.geocities.com/eimworld
<-------------------------------------------------------------------------->
/___________________________________________________________________________\
P.S ===================================================
   If you want , you can register your version with
 sending me 5$(for the world) or 10 levs(Bulgaria) on my post address:
 This program is FREE, but you will recieve new levels and you will
 help me in making new better games.
____________________________________________
[ Bulgaria,Plovdiv **** ,                    ]
[ ******************* for Todor Arnaudov     ]
_____________________________________________]
 In the future three 
 dimentionals with my 3d-engine   TRIGONOMETRIC-3D (TodProg3D) .
     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
            Expect the new games !!!
*** Pac-Man 2000 Hot pursuit - play on this cool game with different than 
   original rules !  
**** Sapper-3D (this is work title) 
      - it will be three dimentional game , it's a continuation of my
        old project for Apple-II machine (fom 1998).
***** Track-field manager - it may be the first simulator of 
        atheltic trainer !!!
****** Bulgarian Soccer manager - may be...
*****  Snake fight-3D - may be it will be with wireframes,because 
         the filling of polygons takes a lot of time... That depends on what
       language I will use then  (?)
  The titles may change ! ;)

   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^         
   Now , enjoy yourself with SNAKE FIGHT !   

 _______________________________________________________________
/________________________ CONTACTS______________________________\
|e-mail: todprog@yahoo.com                                      |
|http://www.geocities.com/todprog                               |
|http://www.geocities.com/eimworld                              | 
|_______________________________________________________________|   